#!/usr/bin/env node

import chalk from "chalk";

const quotes = [
    "Believe in yourself!",
    "Keep pushing forward!",
    "The best time to start is now!",
    "You are capable of amazing things!",
    "Stay positive and work hard!"
];

const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
console.log(chalk.green(`\n✨ ${randomQuote} ✨\n`));

